<?php

echo "Hello World from WebService";

?>